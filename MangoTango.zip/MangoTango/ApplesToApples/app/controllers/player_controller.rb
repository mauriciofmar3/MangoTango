class PlayerController < ApplicationController
end
