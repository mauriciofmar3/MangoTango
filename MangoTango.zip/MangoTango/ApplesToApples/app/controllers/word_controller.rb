class WordController < ApplicationController
end
