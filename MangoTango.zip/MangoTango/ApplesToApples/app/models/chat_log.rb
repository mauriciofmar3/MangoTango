class ChatLog < ActiveRecord::Base
  attr_accessible :data
end
