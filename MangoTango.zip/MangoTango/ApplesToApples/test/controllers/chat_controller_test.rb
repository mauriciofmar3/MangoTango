require 'test_helper'

class ChatControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
