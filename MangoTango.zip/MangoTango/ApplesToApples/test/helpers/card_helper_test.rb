require 'test_helper'

class CardHelperTest < ActionView::TestCase
end
