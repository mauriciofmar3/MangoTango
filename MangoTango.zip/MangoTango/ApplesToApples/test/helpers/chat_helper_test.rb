require 'test_helper'

class ChatHelperTest < ActionView::TestCase
end
