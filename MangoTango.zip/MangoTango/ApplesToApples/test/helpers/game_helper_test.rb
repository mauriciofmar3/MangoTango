require 'test_helper'

class GameHelperTest < ActionView::TestCase
end
