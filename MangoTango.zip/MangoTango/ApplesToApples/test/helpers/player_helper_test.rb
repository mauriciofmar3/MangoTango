require 'test_helper'

class PlayerHelperTest < ActionView::TestCase
end
