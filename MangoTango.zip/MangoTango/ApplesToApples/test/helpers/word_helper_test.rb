require 'test_helper'

class WordHelperTest < ActionView::TestCase
end
